
export type AspectRatio = "1:1" | "3:4" | "4:3" | "9:16" | "16:9";
export type ImageResolution = "1K" | "2K" | "4K";

export interface Scene {
  id: number;
  rawText: string;
  synopsis: string;
  characters: string[];
  setting: string;
}

export interface Character {
  id: string;
  name: string;
  bio: string; // Backstory/Personality
  description: string; // Visual prompt
  imageUrl?: string; 
  referenceImages: string[]; 
}

export interface Item {
  id: string;
  name: string;
  description: string;
  imageUrl?: string;
  referenceImages: string[];
}

export interface Location {
  id: string;
  name: string;
  description: string;
  imageUrl?: string;
  referenceImages: string[];
}

export interface ComicPanel {
  id: string;
  sceneId: number;
  description: string; 
  dialogue: string; 
  imageUrl?: string;
  imageUrlHistory: string[]; 
  isGenerating?: boolean;
}

export interface StyleVariant {
    id: string;
    imageUrl: string;
    prompt: string;
    category: string;
    aspectRatio: AspectRatio;
    resolution: ImageResolution;
}

export type LayoutType = 'grid' | 'webtoon' | 'strip' | 'manga' | 'cinematic' | 'graphic_novel' | 'custom';

export interface GenerationLog {
  timestamp: number;
  message: string;
}

export interface GenerationStatus {
  isActive: boolean;
  progress: number; // 0-100
  startTime: number;
  estimatedTimeRemaining: string; // Formatted string e.g. "2m 30s"
  currentStepDescription: string;
  logs: GenerationLog[];
  completedPanels: number;
  totalPanels: number;
}

export interface ComicState {
  step: number;
  maxStepReached: number; 
  script: string;
  scenes: Scene[];
  
  // Style
  styleVariants: StyleVariant[];
  selectedStyleId?: string;
  stylePrompt: string; 
  styleCategory: string;
  styleAspectRatio: AspectRatio;
  imageResolution: ImageResolution;
  
  // References (World Building)
  characters: Character[];
  items: Item[];
  locations: Location[];
  
  // Layout
  layoutType: LayoutType;
  customLayoutPrompt?: string; 
  
  // Final Output
  panels: ComicPanel[];
  
  // Background Process
  generationStatus?: GenerationStatus;
}

export interface Project {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  coverImage?: string;
  state: ComicState;
}

export interface ChatMessage {
    role: 'user' | 'model';
    text: string;
}

export interface MasterChatSession {
    messages: ChatMessage[];
    isOpen: boolean;
}

export enum AppStep {
  SCRIPT_INPUT = 0,
  STYLE_SELECTION = 1,
  REFERENCE_BUILDER = 2,
  LAYOUT_SELECTION = 3,
  COMBINED_PREVIEW = 4,
  FULL_GENERATION = 5,
  REVIEW_EXPORT = 6
}
