
import React, { useState, useEffect } from 'react';
import { ProjectDashboard } from './components/ProjectDashboard';
import { ComicEditor } from './components/ComicEditor';
import { ComicReader } from './components/ComicReader';
import { MasterAssistant } from './components/MasterAssistant';
import { useProjectManager } from './hooks/useProjectManager';
import { Key, Zap, Loader2 } from 'lucide-react';

const App: React.FC = () => {
  const { projects, createProject, updateProject, deleteProject, duplicateProject, getProject, startGeneration } = useProjectManager();
  const [hasValidKey, setHasValidKey] = useState(false);
  const [isCheckingKey, setIsCheckingKey] = useState(true);
  
  // Simple routing state
  const [currentView, setCurrentView] = useState<'dashboard' | 'editor' | 'reader'>('dashboard');
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);

  useEffect(() => {
    // Check API Key
    const checkKey = async () => {
      try {
        const aiStudio = (window as any).aistudio;
        if (aiStudio) {
          const hasSelected = await aiStudio.hasSelectedApiKey();
          setHasValidKey(hasSelected);
        } else {
          setHasValidKey(!!process.env.API_KEY);
        }
      } catch (e) { console.error("Error checking API key:", e);
      } finally { setIsCheckingKey(false); }
    };
    checkKey();

    // Check URL for shared link access
    const params = new URLSearchParams(window.location.search);
    const view = params.get('view');
    const id = params.get('id');
    if (view === 'read' && id) {
        // Wait for projects to load from localstorage (handled by hook, but simple here)
        setTimeout(() => {
             setActiveProjectId(id);
             setCurrentView('reader');
        }, 100);
    }
  }, []);

  const handleSelectKey = async () => {
    try {
      const aiStudio = (window as any).aistudio;
      if (aiStudio) {
        await aiStudio.openSelectKey();
        setHasValidKey(true);
      }
    } catch (error) { console.error("Key selection failed:", error); }
  };

  const handleCreateProject = (name: string) => {
      const newProject = createProject(name);
      setActiveProjectId(newProject.id);
      setCurrentView('editor');
  };
  
  const handleOpenProject = (id: string) => {
      setActiveProjectId(id);
      setCurrentView('editor');
  };

  const handleReadProject = (id: string) => {
      setActiveProjectId(id);
      setCurrentView('reader');
      // Update URL for sharing without reload
      const url = new URL(window.location.href);
      url.searchParams.set('view', 'read');
      url.searchParams.set('id', id);
      window.history.pushState({}, '', url);
  };

  const handleBackToDashboard = () => {
      setCurrentView('dashboard');
      setActiveProjectId(null);
      const url = new URL(window.location.href);
      url.searchParams.delete('view');
      url.searchParams.delete('id');
      window.history.pushState({}, '', url);
  };

  if (isCheckingKey) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-brand-blue">
        <Loader2 className="w-12 h-12 text-white animate-spin" />
      </div>
    );
  }

  if (!hasValidKey) {
    return (
        <div className="min-h-screen flex items-center justify-center bg-brand-blue p-4">
            <div className="text-center p-8 bg-white rounded-xl border-4 border-black shadow-comic max-w-md transform -rotate-2">
                <Key className="w-16 h-16 mx-auto text-brand-red mb-4" />
                <h1 className="text-4xl font-display mb-2 text-black">Unlock Studio</h1>
                <p className="text-slate-600 font-comic text-lg mb-6 leading-relaxed">
                    To use Gemini 3 Pro Image Generation models, you must select a paid API key from a billing-enabled project.
                </p>
                <button onClick={handleSelectKey} className="w-full bg-brand-yellow text-black font-bold font-comic text-xl py-4 rounded-lg border-2 border-black shadow-comic hover:translate-y-1 hover:shadow-none transition-all mb-6">Select API Key</button>
                <div className="text-xs text-slate-400">
                    Need help? <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-brand-blue hover:text-black underline font-bold">Read Billing Documentation</a>
                </div>
            </div>
        </div>
    );
  }

  const activeProject = activeProjectId ? getProject(activeProjectId) : undefined;

  return (
    <div className="min-h-screen font-sans relative">
      {/* Header */}
      {currentView === 'dashboard' && (
      <header className="h-24 bg-white border-b-4 border-black flex items-center px-6 justify-between relative z-50 shadow-lg">
        <div className="flex items-center gap-3 transform hover:scale-105 transition-transform cursor-default">
          <div className="w-12 h-12 bg-brand-yellow border-2 border-black rounded-lg flex items-center justify-center text-black font-display text-3xl shadow-comic transform -rotate-3">D</div>
          <div className="flex flex-col">
            <span className="font-display text-3xl tracking-tight text-black leading-none" style={{ textShadow: '2px 2px 0px #ddd' }}>DreamStream</span>
            <span className="font-comic font-bold text-brand-blue text-sm leading-none">Comic Studio</span>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-4">
             <button onClick={handleSelectKey} className="text-xs font-bold font-mono text-slate-500 hover:text-brand-blue underline decoration-2 underline-offset-2 transition-colors">CHANGE API KEY</button>
            <div className="flex items-center gap-2 px-4 py-2 bg-black text-white rounded-full font-bold font-mono text-xs border-2 border-white shadow-lg">
                <Zap size={14} className="text-brand-yellow fill-brand-yellow" /> POWERED BY GEMINI 3 PRO
            </div>
        </div>
      </header>
      )}

      {/* Views */}
      {currentView === 'dashboard' && (
          <ProjectDashboard 
            projects={projects}
            onCreateProject={handleCreateProject}
            onOpenProject={handleOpenProject}
            onDeleteProject={deleteProject}
            onDuplicateProject={duplicateProject}
            onReadProject={handleReadProject}
          />
      )}

      {currentView === 'editor' && activeProject && (
          <ComicEditor 
            project={activeProject}
            onUpdate={(updates) => updateProject(activeProject.id, updates)}
            onStartGeneration={startGeneration}
            onBack={handleBackToDashboard}
          />
      )}

      {currentView === 'reader' && activeProject && (
          <ComicReader 
            project={activeProject}
            onClose={handleBackToDashboard}
          />
      )}
      
      {/* Global Master Assistant */}
      <MasterAssistant 
        currentView={currentView}
        activeProject={activeProject}
      />
    </div>
  );
};

export default App;
