import { useState, useEffect } from 'react';
import { Project, ComicState, AppStep, ComicPanel } from '../types';
import { startBackgroundGeneration } from '../services/generationManager';

const STORAGE_KEY = 'dreamstream_projects';

const INITIAL_STATE: ComicState = {
    step: AppStep.SCRIPT_INPUT,
    maxStepReached: AppStep.SCRIPT_INPUT,
    script: '',
    scenes: [],
    styleVariants: [],
    selectedStyleId: undefined,
    stylePrompt: '',
    styleCategory: '',
    styleAspectRatio: '1:1',
    imageResolution: '1K',
    characters: [],
    items: [],
    locations: [],
    layoutType: 'grid',
    customLayoutPrompt: undefined,
    panels: [],
};

export const useProjectManager = () => {
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setProjects(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load projects", e);
      }
    }
  }, []);

  const saveProjects = (newProjects: Project[]) => {
    setProjects(newProjects);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newProjects));
  };

  const createProject = (name: string): Project => {
    const newProject: Project = {
      id: crypto.randomUUID(),
      name,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      state: { ...INITIAL_STATE }
    };
    saveProjects([newProject, ...projects]);
    return newProject;
  };

  const updateProject = (id: string, updates: Partial<Project> | ((prev: Project) => Partial<Project>)) => {
    setProjects(prevProjects => {
        const newProjects = prevProjects.map(p => {
            if (p.id === id) {
                const newValues = typeof updates === 'function' ? updates(p) : updates;
                return { ...p, ...newValues, updatedAt: Date.now() };
            }
            return p;
        });
        // Side effect: save to local storage
        localStorage.setItem(STORAGE_KEY, JSON.stringify(newProjects));
        return newProjects;
    });
  };

  // Wrapper to call standard updateProject but also persist to storage (handled by updateProject logic above if we lift saveProjects out or duplicate)
  // To avoid race conditions in React state vs LocalStorage, we rely on the setProjects functional update callback pattern mostly.
  
  const deleteProject = (id: string) => {
    saveProjects(projects.filter(p => p.id !== id));
  };

  const duplicateProject = (id: string) => {
    const original = projects.find(p => p.id === id);
    if (original) {
        const copy: Project = {
            ...original,
            id: crypto.randomUUID(),
            name: `${original.name} (Copy)`,
            createdAt: Date.now(),
            updatedAt: Date.now(),
            state: {
                ...original.state,
                panels: [], // Reset generated panels on duplicate? Or keep? Let's keep for "forking".
                generationStatus: undefined // Reset active generation
            }
        };
        saveProjects([copy, ...projects]);
    }
  };

  const getProject = (id: string) => projects.find(p => p.id === id);

  const startGeneration = (projectId: string) => {
    const project = getProject(projectId);
    if (!project) return;

    // Start the background process
    startBackgroundGeneration(
        project,
        updateProject, // Pass the updater
        (pid, panels) => {
             // On Complete
             // Optionally trigger sound here if valid context, or handle in UI
        }
    );
  };

  return {
    projects,
    createProject,
    updateProject,
    deleteProject,
    duplicateProject,
    getProject,
    startGeneration
  };
};