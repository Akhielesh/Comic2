import React, { useState, useEffect } from 'react';
import { Plus, BookOpen, Edit, Trash2, Copy, LayoutGrid, Sparkles, PenTool, Zap, CheckCircle2, XCircle, AlertTriangle } from 'lucide-react';
import { Project } from '../types';
import { Button } from './Button';

interface ProjectDashboardProps {
  projects: Project[];
  onCreateProject: (name: string) => void;
  onOpenProject: (id: string) => void;
  onDeleteProject: (id: string) => void;
  onDuplicateProject: (id: string) => void;
  onReadProject: (id: string) => void;
}

// System Health Checklist Component
const SystemStatus = () => {
    const [checks, setChecks] = useState<{name: string, status: 'ok' | 'error' | 'warning', msg: string}[]>([]);

    useEffect(() => {
        const runChecks = async () => {
            const results = [];
            
            // 1. API Key
            const hasKey = (window as any).aistudio?.hasSelectedApiKey?.() || process.env.API_KEY;
            results.push({ 
                name: "Gemini API Access", 
                status: hasKey ? 'ok' : 'error', 
                msg: hasKey ? "Ready" : "Missing API Key" 
            });

            // 2. Storage
            try {
                localStorage.setItem('test', 'test');
                localStorage.removeItem('test');
                results.push({ name: "Local Storage", status: 'ok', msg: "Ready" });
            } catch (e) {
                results.push({ name: "Local Storage", status: 'error', msg: "Full or Disabled" });
            }

            // 3. PDF Libs
            const hasPDF = (window as any).jspdf && (window as any).html2canvas;
            results.push({ 
                name: "PDF Engine", 
                status: hasPDF ? 'ok' : 'warning', 
                msg: hasPDF ? "Loaded" : "Libraries Loading..." 
            });

            // 4. Audio
            const hasAudio = window.AudioContext || (window as any).webkitAudioContext;
            results.push({ 
                name: "Audio Engine", 
                status: hasAudio ? 'ok' : 'warning', 
                msg: hasAudio ? "Ready" : "Not Supported" 
            });

            setChecks(results as any);
        };
        
        runChecks();
        // Re-check periodically just in case
        const interval = setInterval(runChecks, 5000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="bg-white p-4 rounded-xl border-4 border-black shadow-comic mb-8">
            <h3 className="font-display text-lg mb-3 flex items-center gap-2"><Zap className="text-brand-yellow fill-brand-yellow"/> System Diagnostic</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {checks.map((c, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm font-bold border-2 border-slate-100 p-2 rounded bg-slate-50">
                        {c.status === 'ok' && <CheckCircle2 className="text-green-500 w-5 h-5"/>}
                        {c.status === 'error' && <XCircle className="text-red-500 w-5 h-5"/>}
                        {c.status === 'warning' && <AlertTriangle className="text-yellow-500 w-5 h-5"/>}
                        <div>
                            <div className="text-black">{c.name}</div>
                            <div className="text-xs text-slate-500 font-mono uppercase">{c.msg}</div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export const ProjectDashboard: React.FC<ProjectDashboardProps> = ({ 
  projects, onCreateProject, onOpenProject, onDeleteProject, onDuplicateProject, onReadProject 
}) => {
  const [isCreating, setIsCreating] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');

  const handleCreate = () => {
    if (newProjectName.trim()) {
      onCreateProject(newProjectName);
      setNewProjectName('');
      setIsCreating(false);
    }
  };

  const renderLanding = () => (
      <div className="text-center py-20 space-y-12 animate-fade-in">
          <div className="space-y-6 max-w-3xl mx-auto">
              <div className="inline-block bg-black text-white px-4 py-1 rounded-full font-mono text-xs font-bold tracking-widest mb-4 animate-bounce">
                  V 2.0 NOW LIVE
              </div>
              <h1 className="text-7xl font-display text-black leading-tight">
                  Turn Your <span className="text-brand-blue">Script</span> Into A <span className="text-brand-yellow bg-black px-4 transform -skew-x-12 inline-block">Comic</span>
              </h1>
              <p className="text-xl font-comic text-slate-600 max-w-2xl mx-auto">
                  The professional AI studio for storytellers. Create consistent characters, stunning layouts, and full graphic novels in minutes.
              </p>
          </div>

          <div className="flex justify-center gap-6">
              <Button onClick={() => setIsCreating(true)} className="text-xl px-12 py-6" icon={<Sparkles/>}>Start Creating Now</Button>
          </div>

          <SystemStatus />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto mt-8 text-left">
               <div className="bg-white p-6 rounded-xl border-4 border-black shadow-comic">
                   <div className="w-12 h-12 bg-brand-blue rounded-lg border-2 border-black flex items-center justify-center mb-4 text-white"><PenTool/></div>
                   <h3 className="font-display text-xl mb-2">Script to Scene</h3>
                   <p className="font-comic text-sm text-slate-600">Paste your story. We'll break it down, identifying characters, settings, and action automatically.</p>
               </div>
               <div className="bg-white p-6 rounded-xl border-4 border-black shadow-comic">
                   <div className="w-12 h-12 bg-brand-yellow rounded-lg border-2 border-black flex items-center justify-center mb-4 text-black"><LayoutGrid/></div>
                   <h3 className="font-display text-xl mb-2">Smart Layouts</h3>
                   <p className="font-comic text-sm text-slate-600">Choose from Manga, Webtoon, or Classic Grids. Or upload your own sketch for a custom layout.</p>
               </div>
               <div className="bg-white p-6 rounded-xl border-4 border-black shadow-comic">
                   <div className="w-12 h-12 bg-brand-red rounded-lg border-2 border-black flex items-center justify-center mb-4 text-white"><Zap/></div>
                   <h3 className="font-display text-xl mb-2">Consistent Cast</h3>
                   <p className="font-comic text-sm text-slate-600">Define your characters once. Our AI keeps their look consistent across every panel and page.</p>
               </div>
          </div>
      </div>
  );

  return (
    <div className="max-w-7xl mx-auto p-8 animate-fade-in">
        {projects.length > 0 && (
            <>
            <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-brand-yellow border-4 border-black rounded-xl flex items-center justify-center shadow-comic transform -rotate-3">
                        <LayoutGrid className="w-8 h-8 text-black" />
                    </div>
                    <div>
                        <h1 className="text-4xl font-display text-black">My Comics</h1>
                        <p className="text-slate-600 font-comic font-bold">Manage your studio projects</p>
                    </div>
                </div>
                <Button onClick={() => setIsCreating(true)} icon={<Plus/>}>New Comic</Button>
            </div>
            <SystemStatus />
            </>
        )}

        {isCreating && (
            <div className="mb-12 mx-auto bg-white p-6 rounded-xl border-4 border-black shadow-comic max-w-xl relative z-50">
                <label className="block text-lg font-display mb-2 text-black">Comic Title</label>
                <div className="flex gap-4">
                    <input 
                        autoFocus
                        type="text" 
                        value={newProjectName}
                        onChange={(e) => setNewProjectName(e.target.value)}
                        placeholder="The Amazing Adventures of..." 
                        className="flex-1 border-2 border-black bg-white text-black rounded-lg px-4 py-2 font-comic text-lg focus:shadow-comic outline-none transition-all placeholder-slate-400"
                        onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
                    />
                    <Button onClick={handleCreate}>Create</Button>
                    <Button variant="secondary" onClick={() => setIsCreating(false)}>Cancel</Button>
                </div>
            </div>
        )}

        {projects.length === 0 ? renderLanding() : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects.map(project => (
                    <div key={project.id} className="group bg-white rounded-xl border-4 border-black shadow-comic hover:-translate-y-2 hover:shadow-[8px_8px_0px_0px_#000] transition-all duration-300 flex flex-col overflow-hidden">
                        <div className="aspect-video bg-slate-100 border-b-4 border-black relative overflow-hidden">
                            {project.state.panels.length > 0 ? (
                                <img src={project.state.panels[0].imageUrl} className="w-full h-full object-cover" />
                            ) : project.state.styleVariants.length > 0 ? (
                                <img src={project.state.styleVariants[0].imageUrl} className="w-full h-full object-cover opacity-50 grayscale" />
                            ) : (
                                <div className="w-full h-full flex items-center justify-center bg-brand-blue/10 text-brand-blue/50 font-display text-6xl">?</div>
                            )}
                             
                             {project.state.generationStatus?.isActive && (
                                <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-white p-4">
                                    <div className="text-brand-yellow font-display text-2xl animate-pulse mb-2">Generating...</div>
                                    <div className="w-full h-2 bg-white/20 rounded-full mb-2 overflow-hidden">
                                        <div className="h-full bg-brand-yellow transition-all duration-500" style={{width: `${project.state.generationStatus.progress}%`}}/>
                                    </div>
                                    <div className="font-mono text-xs text-slate-300">Est: {project.state.generationStatus.estimatedTimeRemaining}</div>
                                </div>
                             )}

                             <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity gap-2">
                                <Button size="sm" onClick={() => onReadProject(project.id)} icon={<BookOpen size={16}/>}>Read</Button>
                                <Button size="sm" variant="secondary" onClick={() => onOpenProject(project.id)} icon={<Edit size={16}/>}>Edit</Button>
                             </div>
                        </div>
                        <div className="p-5">
                            <h3 className="text-2xl font-display truncate mb-1">{project.name}</h3>
                            <div className="flex justify-between items-center mb-4">
                                <p className="text-xs text-slate-500 font-mono">Updated: {new Date(project.updatedAt).toLocaleDateString()}</p>
                                {project.state.generationStatus?.isActive && <span className="text-xs font-bold bg-brand-yellow px-2 py-0.5 rounded border border-black animate-pulse">BUILDING</span>}
                            </div>
                            
                            <div className="flex justify-between border-t-2 border-slate-100 pt-4">
                                <button onClick={() => onDuplicateProject(project.id)} className="text-slate-500 hover:text-brand-blue flex items-center gap-1 text-xs font-bold uppercase">
                                    <Copy size={14}/> Duplicate
                                </button>
                                <button onClick={() => onDeleteProject(project.id)} className="text-slate-500 hover:text-brand-red flex items-center gap-1 text-xs font-bold uppercase">
                                    <Trash2 size={14}/> Delete
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        )}
    </div>
  );
};