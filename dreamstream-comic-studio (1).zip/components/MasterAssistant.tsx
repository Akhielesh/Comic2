
import React, { useState, useRef, useEffect } from 'react';
import { Bot, X, Send, Sparkles, MessageSquare } from 'lucide-react';
import { Project, ChatMessage } from '../types';
import { queryMasterAssistant } from '../services/geminiService';

interface MasterAssistantProps {
  activeProject?: Project;
  currentView: 'dashboard' | 'editor' | 'reader';
}

export const MasterAssistant: React.FC<MasterAssistantProps> = ({ activeProject, currentView }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: "Hello! I'm your DreamStream Studio Assistant. I can help you create your comic, fix issues, or explain features. What's on your mind?" }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const userMsg: ChatMessage = { role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const responseText = await queryMasterAssistant(
          userMsg.text, 
          messages, 
          { view: currentView, project: activeProject }
      );
      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (e) {
      console.error(e);
      setMessages(prev => [...prev, { role: 'model', text: "System Error: Unable to process request." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <>
      {/* Floating Toggle Button */}
      {!isOpen && (
        <button 
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 left-6 z-50 w-14 h-14 bg-black text-brand-yellow border-4 border-white rounded-full shadow-comic hover:scale-110 transition-transform flex items-center justify-center group"
          aria-label="Open Assistant"
        >
          <Sparkles className="w-8 h-8 group-hover:animate-spin" />
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-6 left-6 z-50 w-96 h-[500px] bg-white rounded-xl border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,0.5)] flex flex-col overflow-hidden animate-fade-in">
          {/* Header */}
          <div className="bg-black text-brand-yellow p-4 flex justify-between items-center shrink-0">
            <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-brand-yellow rounded-full flex items-center justify-center border-2 border-white text-black">
                    <Bot size={20} />
                </div>
                <h3 className="font-display text-lg tracking-wide">Studio Assistant</h3>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-white hover:text-brand-red transition-colors">
                <X size={24} />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50 custom-scrollbar">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-3 rounded-lg text-sm font-medium border-2 border-black shadow-sm ${
                  msg.role === 'user' ? 'bg-white text-black rounded-tr-none' : 'bg-brand-blue text-white rounded-tl-none'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
            {isTyping && (
                <div className="flex justify-start">
                    <div className="bg-brand-blue/50 text-white p-2 rounded-lg rounded-tl-none text-xs animate-pulse">
                        Analyzing Project State...
                    </div>
                </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-3 bg-white border-t-4 border-black">
            <div className="flex gap-2">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask for help..."
                className="flex-1 bg-slate-100 border-2 border-black rounded px-3 py-2 text-sm focus:outline-none focus:bg-white transition-colors"
              />
              <button 
                onClick={handleSend}
                disabled={!input.trim() || isTyping}
                className="bg-brand-yellow border-2 border-black rounded p-2 hover:bg-black hover:text-brand-yellow transition-colors disabled:opacity-50"
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
