import React, { useState } from 'react';
import { Project } from '../types';
import { AiAssistant } from './AiAssistant';
import { X, MessageCircle } from 'lucide-react';

interface ComicReaderProps {
  project: Project;
  onClose: () => void;
}

export const ComicReader: React.FC<ComicReaderProps> = ({ project, onClose }) => {
  const [showChat, setShowChat] = useState(false);

  return (
    <div className="fixed inset-0 z-50 bg-slate-100 overflow-hidden flex flex-col">
      {/* Reader Header */}
      <header className="h-16 bg-white border-b-4 border-black flex items-center justify-between px-6 shadow-lg shrink-0">
        <h1 className="font-display text-2xl text-black truncate">{project.name}</h1>
        <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
            <X className="w-6 h-6" />
        </button>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Main Comic Area */}
        <div className="flex-1 overflow-y-auto custom-scrollbar bg-slate-200 p-4 md:p-8 flex justify-center">
            <div className="max-w-4xl w-full bg-white shadow-2xl min-h-full">
                <div className={`p-8 grid gap-6 ${
                    project.state.layoutType === 'webtoon' ? 'flex flex-col items-center' : 
                    project.state.layoutType === 'strip' ? 'flex flex-col gap-2' : 
                    'grid-cols-1 md:grid-cols-2'
                }`}>
                    {project.state.panels.map((panel, idx) => (
                        <div key={idx} className="border-2 border-black shadow-sm relative">
                             <img src={panel.imageUrl} alt={panel.description} className="w-full h-auto" />
                             {panel.dialogue && (
                                 <div className="bg-white/90 border-2 border-black p-2 absolute bottom-4 left-4 right-4 text-center font-comic font-bold text-sm md:text-base rounded shadow-sm">
                                    {panel.dialogue}
                                 </div>
                             )}
                        </div>
                    ))}
                    {project.state.panels.length === 0 && (
                        <div className="col-span-full text-center py-20 text-slate-400 font-display text-2xl">
                            This comic hasn't been drawn yet!
                        </div>
                    )}
                </div>
            </div>
        </div>

        {/* Sidebar (Chat) */}
        <div className={`
            fixed md:relative inset-y-0 right-0 w-full md:w-96 bg-white border-l-4 border-black transform transition-transform duration-300 z-40
            ${showChat ? 'translate-x-0' : 'translate-x-full md:translate-x-0 md:w-0 md:border-none'}
        `}>
            <div className="h-full w-full md:w-96 border-l-4 border-black md:border-none">
                 <AiAssistant script={project.state.script} />
            </div>
             {/* Mobile Close Chat */}
            <button onClick={() => setShowChat(false)} className="absolute top-4 right-4 md:hidden p-2 bg-black text-white rounded-full">
                <X size={20}/>
            </button>
        </div>
      </div>

      {/* Floating Chat Toggle for Mobile/Tablet */}
      <button 
        onClick={() => setShowChat(!showChat)}
        className="md:hidden fixed bottom-6 right-6 w-14 h-14 bg-brand-yellow border-4 border-black rounded-full flex items-center justify-center shadow-comic z-50"
      >
        <MessageCircle className="w-8 h-8 text-black" />
      </button>
    </div>
  );
};