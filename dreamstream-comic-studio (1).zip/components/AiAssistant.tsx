import React, { useState, useEffect, useRef } from 'react';
import { Send, Bot, User } from 'lucide-react';
import { startChatWithScript } from '../services/geminiService';
import { ChatMessage } from '../types';
import { GenerateContentResponse } from '@google/genai';

interface AiAssistantProps {
  script: string;
}

export const AiAssistant: React.FC<AiAssistantProps> = ({ script }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: "Hi! I'm the Assistant for this comic. Ask me anything about the story, characters, or hidden details!" }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (script) {
      chatRef.current = startChatWithScript(script);
    }
  }, [script]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || !chatRef.current) return;
    
    const userMsg: ChatMessage = { role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const response: GenerateContentResponse = await chatRef.current.sendMessage({ message: userMsg.text });
      const text = response.text || "I couldn't find an answer to that in the script.";
      setMessages(prev => [...prev, { role: 'model', text }]);
    } catch (e) {
      console.error(e);
      setMessages(prev => [...prev, { role: 'model', text: "Oops, I had trouble reading the script right now." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white border-l-4 border-black">
      <div className="p-4 bg-brand-yellow border-b-4 border-black flex items-center gap-2">
        <Bot className="w-6 h-6" />
        <h3 className="font-display text-xl">Story Assistant</h3>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50 custom-scrollbar">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] p-3 rounded-lg text-sm font-medium border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,0.1)] ${
              msg.role === 'user' ? 'bg-white text-black rounded-tr-none' : 'bg-brand-blue text-white rounded-tl-none'
            }`}>
              {msg.text}
            </div>
          </div>
        ))}
        {isTyping && (
             <div className="flex justify-start">
                <div className="bg-brand-blue text-white p-3 rounded-lg rounded-tl-none border-2 border-black text-xs font-bold animate-pulse">
                    Thinking...
                </div>
             </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t-4 border-black bg-white">
        <div className="flex gap-2">
          <input 
            type="text" 
            value={input} 
            onChange={(e) => setInput(e.target.value)} 
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask about the story..."
            className="flex-1 border-2 border-black rounded-lg px-3 py-2 text-sm focus:shadow-comic focus:outline-none transition-all"
          />
          <button onClick={handleSend} disabled={!input.trim() || isTyping} className="bg-black text-white p-2 rounded-lg hover:bg-brand-yellow hover:text-black transition-colors">
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};