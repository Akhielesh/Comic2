import React, { useState } from 'react';
import { Download, Edit2, RefreshCw, X, History, Share2, FileCode } from 'lucide-react';
import { ComicPanel, ComicState } from '../../types';
import { generateImage } from '../../services/geminiService';
import { Button } from '../Button';
import { ImagePreviewModal } from '../modals/ImagePreviewModal';
import { RegenerateModal } from '../modals/RegenerateModal';

declare const jspdf: any;
declare const html2canvas: any;

interface ReviewExportProps {
  panels: ComicPanel[];
  state: ComicState;
  onUpdatePanel: (panelId: string, newUrl: string) => void;
}

export const ReviewExport: React.FC<ReviewExportProps> = ({ panels, state, onUpdatePanel }) => {
  const [selectedPanel, setSelectedPanel] = useState<ComicPanel | null>(panels[0] || null);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [showRegenModal, setShowRegenModal] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [shareLink, setShareLink] = useState<string | null>(null);

  const handleRegenerate = async (instructions: string) => {
    if (!selectedPanel) return;
    setIsRegenerating(true);
    setShowRegenModal(false);
    try {
      const prompt = `
        Regenerate this comic panel with the following changes: ${instructions}.
        Original Context: ${selectedPanel.description}.
        Style: ${state.stylePrompt}.
        Characters: ${state.scenes.find(s => s.id === selectedPanel.sceneId)?.characters.join(', ')}.
        Maintain character consistency based on reference sheets.
      `;
      const url = await generateImage(prompt, state.styleAspectRatio, state.imageResolution);
      if (url) {
        onUpdatePanel(selectedPanel.id, url);
        setSelectedPanel(prev => prev ? { ...prev, imageUrl: url, imageUrlHistory: [...prev.imageUrlHistory, url] } : null);
      }
    } catch (e) {
        console.error(e);
    } finally {
      setIsRegenerating(false);
    }
  };
  
  const handleDownloadPDF = async () => {
    const comicEl = document.getElementById('comic-render-area');
    if (!comicEl) return;
    
    const { jsPDF } = jspdf;
    const pdf = new jsPDF(state.styleAspectRatio === '9:16' ? 'p' : 'l', 'mm', 'a4');
    
    // Temporarily expand full height to capture everything
    const originalHeight = comicEl.style.height;
    const originalOverflow = comicEl.style.overflow;
    comicEl.style.height = 'auto';
    comicEl.style.overflow = 'visible';

    try {
        const canvas = await html2canvas(comicEl, { scale: 2, backgroundColor: '#FFFFFF' });
        const imgData = canvas.toDataURL('image/png');
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
        
        // Split into pages if too long
        if (pdfHeight > pdf.internal.pageSize.getHeight()) {
             let heightLeft = pdfHeight;
             let position = 0;
             const pageHeight = pdf.internal.pageSize.getHeight();

             pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
             heightLeft -= pageHeight;

             while (heightLeft >= 0) {
               position = heightLeft - pdfHeight;
               pdf.addPage();
               pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
               heightLeft -= pageHeight;
             }
        } else {
             pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
        }
        
        pdf.save('dreamstream-comic.pdf');
    } finally {
        comicEl.style.height = originalHeight;
        comicEl.style.overflow = originalOverflow;
    }
  };

  const handleDownloadHTML = () => {
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head><title>My Comic</title><style>body{margin:0;padding:20px;background:#eee;font-family:sans-serif;} .comic-container{max-width:800px;margin:0 auto;background:white;padding:20px;box-shadow:0 4px 6px rgba(0,0,0,0.1);} img{width:100%;display:block;margin-bottom:20px;border:2px solid black;}</style></head>
      <body>
        <div class="comic-container">
          ${panels.map(p => `<div class="panel"><img src="${p.imageUrl}" /><p style="text-align:center;font-weight:bold;">${p.dialogue || ''}</p></div>`).join('')}
        </div>
      </body>
      </html>
    `;
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'comic.html';
    a.click();
  };

  const handleShare = () => {
     const url = new URL(window.location.href);
     // Assuming we rely on the parent updating the URL, or just copy current
     const shareUrl = url.toString().replace('view=edit', 'view=read');
     setShareLink(shareUrl);
     navigator.clipboard.writeText(shareUrl);
     setTimeout(() => setShareLink(null), 3000);
  };

  const getLayoutClass = () => {
    switch(state.layoutType) {
        case 'webtoon': return 'flex flex-col items-center gap-4';
        case 'strip': return 'flex flex-col items-center gap-2';
        case 'grid':
        case 'custom':
        default:
            return `grid grid-cols-2 gap-4 auto-rows-fr`;
    }
  };

  return (
    <div className="h-[calc(100vh-180px)] flex flex-col md:flex-row gap-6 animate-fade-in">
        {/* Main Editor Area */}
        <div className="flex-1 flex flex-col gap-6">
            <div id="comic-render-area" className="flex-1 bg-white rounded-xl border-4 border-black shadow-comic p-8 overflow-y-auto custom-scrollbar">
                <div className={getLayoutClass()}>
                    {panels.map((panel, idx) => (
                        <div 
                            key={panel.id} 
                            className="relative group border-4 border-black rounded-lg overflow-hidden shadow-comic cursor-pointer" 
                            onClick={() => setSelectedPanel(panel)}
                        >
                            <img src={panel.imageUrl} alt={`Panel ${idx+1}`} className="w-full h-full object-cover"/>
                            {panel.dialogue && <div className="absolute bottom-2 left-2 right-2 bg-white/90 p-2 text-sm font-comic font-bold text-black border-2 border-black rounded">{panel.dialogue}</div>}
                            
                            {/* Hover Overlay */}
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                <button className="bg-white p-2 rounded-full hover:bg-brand-yellow border-2 border-black" onClick={(e) => {e.stopPropagation(); setPreviewImage(panel.imageUrl!)}}><Edit2 size={16}/></button>
                            </div>

                            {selectedPanel?.id === panel.id && <div className="absolute inset-0 ring-4 ring-brand-yellow ring-offset-2 pointer-events-none"/>}
                        </div>
                    ))}
                </div>
            </div>

            {/* Action Bar */}
            <div className="h-24 bg-white border-4 border-black rounded-xl p-4 flex items-center justify-between shadow-comic">
                 <div className="flex items-center gap-4">
                     <Button variant="secondary" onClick={() => setShowRegenModal(true)} disabled={!selectedPanel} isLoading={isRegenerating} icon={<RefreshCw className="w-4 h-4" />}>Regenerate</Button>
                     <Button variant="outline" onClick={() => setShowHistoryModal(true)} disabled={!selectedPanel || selectedPanel.imageUrlHistory.length <= 1} icon={<History className="w-4 h-4" />}>History</Button>
                 </div>
                 <div className="flex items-center gap-4">
                     <button onClick={handleShare} className="flex items-center gap-2 text-sm font-bold text-slate-600 hover:text-black">
                        <Share2 size={16}/> {shareLink ? "Link Copied!" : "Share"}
                     </button>
                     <div className="flex gap-2">
                        <Button onClick={handleDownloadHTML} variant="outline" icon={<FileCode className="w-4 h-4" />}>HTML</Button>
                        <Button onClick={handleDownloadPDF} icon={<Download className="w-4 h-4" />} className="bg-brand-yellow">PDF</Button>
                     </div>
                 </div>
            </div>
        </div>
        
        {/* History Modal */}
        {showHistoryModal && selectedPanel && (
            <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setShowHistoryModal(false)}>
                <div className="bg-white rounded-xl border-4 border-black shadow-comic w-full max-w-4xl max-h-[80vh] flex flex-col p-6" onClick={e => e.stopPropagation()}>
                    <div className="flex justify-between items-center mb-4">
                         <h3 className="text-2xl font-display">Version History for Panel</h3>
                         <button onClick={() => setShowHistoryModal(false)} className="p-2 rounded-full hover:bg-slate-100"><X/></button>
                    </div>
                    <div className="flex-1 overflow-y-auto grid grid-cols-2 md:grid-cols-4 gap-4 custom-scrollbar pr-2">
                        {selectedPanel.imageUrlHistory.map((url, idx) => (
                            <div key={idx} className="aspect-square relative group">
                                <img src={url} className="w-full h-full object-cover rounded-lg border-2 border-black"/>
                                <button onClick={() => { onUpdatePanel(selectedPanel.id, url); setShowHistoryModal(false); }} className="absolute inset-0 bg-black/50 text-white font-bold text-sm items-center justify-center hidden group-hover:flex">Use This Version</button>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        )}

        {showRegenModal && selectedPanel && selectedPanel.imageUrl && (
            <RegenerateModal 
                currentImageUrl={selectedPanel.imageUrl} 
                isLoading={isRegenerating}
                onConfirm={handleRegenerate}
                onClose={() => setShowRegenModal(false)}
            />
        )}

        {previewImage && <ImagePreviewModal imageUrl={previewImage} onClose={() => setPreviewImage(null)} />}
    </div>
  );
};