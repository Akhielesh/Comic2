import React, { useState, useEffect } from 'react';
import { Sparkles, ArrowRight, Pencil } from 'lucide-react';
import { analyzeScript } from '../../services/geminiService';
import { Scene } from '../../types';
import { Button } from '../Button';

interface ScriptInputProps {
  initialScript: string;
  onScenesGenerated: (script: string, scenes: Scene[]) => void;
  onScriptChange: (script: string) => void;
}

export const ScriptInput: React.FC<ScriptInputProps> = ({ initialScript, onScenesGenerated, onScriptChange }) => {
  const [script, setScript] = useState(initialScript);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Sync with initialScript if it changes externally (e.g. loading a project)
  useEffect(() => {
    setScript(initialScript);
  }, [initialScript]);

  const handleChange = (newScript: string) => {
    setScript(newScript);
    onScriptChange(newScript);
  };

  const handleAnalyze = async () => {
    if (!script.trim()) return;
    setIsAnalyzing(true);
    setError(null);
    
    try {
      const scenes = await analyzeScript(script);
      if (scenes && scenes.length > 0) {
        onScenesGenerated(script, scenes);
      } else {
        setError("Could not identify scenes. Please check the format.");
      }
    } catch (e) {
      console.error(e);
      setError("Failed to analyze script. Ensure API Key is set and valid.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const sampleScript = `Scene 1: A futuristic cityscape at night. Neon rain falls. DETECTIVE K, a cyborg in a trench coat, stands on a rooftop looking at a holographic billboard.

Scene 2: Inside a noodle bar. It is crowded and smoky. K sits at the counter. A mysterious woman in red, VIVIAN, approaches him holding a datapad.

VIVIAN: "You're looking for the ghost in the machine, aren't you?"
K: "I'm just looking for dinner."`;

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fade-in">
      <div className="text-center space-y-2 bg-white p-6 rounded-xl border-4 border-black shadow-comic transform -rotate-1">
        <h2 className="text-4xl font-display text-black">The Story Begins!</h2>
        <p className="text-slate-600 font-comic text-lg">Paste your script below. Gemini will break it down into scenes for you.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-4">
            <div className="relative group">
                <div className="absolute -top-3 -left-3 bg-brand-yellow px-3 py-1 border-2 border-black font-bold font-comic shadow-sm z-10 rotate-[-2deg]">
                    SCRIPT EDITOR
                </div>
                <textarea
                    value={script}
                    onChange={(e) => handleChange(e.target.value)}
                    placeholder="Paste your script here..."
                    className="w-full h-96 bg-white border-4 border-black rounded-xl p-6 text-slate-800 placeholder-slate-400 focus:ring-0 focus:border-brand-blue focus:shadow-comic transition-all resize-none font-mono text-sm leading-relaxed shadow-[4px_4px_0px_0px_rgba(0,0,0,0.2)]"
                />
                <div className="absolute bottom-4 right-4">
                     <button onClick={() => handleChange(sampleScript)} className="text-xs font-bold bg-slate-100 px-3 py-1 rounded border-2 border-black hover:bg-brand-yellow transition-colors">
                        Load Sample
                     </button>
                </div>
            </div>
        </div>

        <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl border-4 border-black shadow-comic relative overflow-hidden">
                <div className="absolute top-0 right-0 w-16 h-16 bg-brand-blue/20 rounded-bl-full -mr-8 -mt-8"></div>
                <h3 className="text-xl font-display text-black mb-4 flex items-center">
                    <Sparkles className="w-6 h-6 text-brand-yellow fill-brand-yellow mr-2" />
                    AI Analysis
                </h3>
                <p className="text-sm text-slate-600 font-medium mb-4 leading-relaxed">
                    We use <strong className="text-brand-blue">Gemini 3 Pro</strong> with Thinking Mode to deeply understand the nuances, characters, and setting of your story.
                </p>
                <ul className="space-y-3 text-sm font-bold text-slate-700">
                    <li className="flex items-center"><div className="w-3 h-3 border-2 border-black bg-brand-yellow mr-2"/> Scene Detection</li>
                    <li className="flex items-center"><div className="w-3 h-3 border-2 border-black bg-brand-red mr-2"/> Character Extraction</li>
                    <li className="flex items-center"><div className="w-3 h-3 border-2 border-black bg-brand-blue mr-2"/> Setting Visualization</li>
                </ul>
            </div>

            <Button 
                onClick={handleAnalyze} 
                isLoading={isAnalyzing}
                className="w-full py-6 text-xl"
                icon={<ArrowRight />}
                disabled={script.length < 10}
            >
                Analyze Script
            </Button>
            
            {error && (
                <div className="p-4 bg-red-100 border-4 border-brand-red text-brand-red font-bold text-sm rounded-xl shadow-comic">
                    {error}
                </div>
            )}
        </div>
      </div>
    </div>
  );
};