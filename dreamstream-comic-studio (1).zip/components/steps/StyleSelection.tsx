
import React, { useState, useEffect, useRef } from 'react';
import { RefreshCw, CheckCircle, Image as ImageIcon, Palette, AlertCircle, PlusCircle, Check, ArrowLeft, Wand2, Loader2 } from 'lucide-react';
import { generateImage, analyzeScript } from '../../services/geminiService';
import { Scene, AspectRatio, ImageResolution, StyleVariant } from '../../types';
import { Button } from '../Button';
import { ImagePreviewModal } from '../modals/ImagePreviewModal';

interface StyleSelectionProps {
  firstScene?: Scene;
  script: string;
  onScenesGenerated: (scenes: Scene[]) => void;
  onStyleConfirmed: (style: StyleVariant) => void;
  initialVariants: StyleVariant[];
  onVariantsChange: (variants: StyleVariant[]) => void;
  selectedStyleId?: string;
  onBackToScript?: () => void;
  onScriptUpdate?: (script: string) => void;
}

const STYLE_PRESETS = [
  { id: 'manga-bw', label: 'Manga (B&W)', prompt: 'Manga style, black and white, high contrast, screentones, intricate line art' },
  { id: 'western-comic', label: 'Modern Western', prompt: 'Modern western comic book style, vibrant colors, dynamic shading, sharp outlines, marvel/dc style' },
  { id: 'noir', label: 'Noir / Sin City', prompt: 'Film noir graphic novel style, extreme chiaroscuro, black white and one accent color, moody' },
  { id: 'webtoon', label: 'Webtoon / Anime', prompt: 'Webtoon digital art style, soft shading, anime aesthetics, bright cel shading' },
  { id: 'watercolor', label: 'Watercolor', prompt: 'Watercolor graphic novel style, artistic, dreamy, soft edges, painterly texture' },
  { id: 'cyberpunk', label: 'Cyberpunk', prompt: 'Cyberpunk neon aesthetic, digital painting, highly detailed, glowing lights, gritty futuristic' },
];

const ASPECT_RATIOS: AspectRatio[] = ["1:1", "3:4", "4:3", "9:16", "16:9"];
const RESOLUTIONS: ImageResolution[] = ["1K", "2K", "4K"];

export const StyleSelection: React.FC<StyleSelectionProps> = ({ 
    firstScene, script, onScenesGenerated, onStyleConfirmed, initialVariants, onVariantsChange, selectedStyleId, onBackToScript, onScriptUpdate
}) => {
  const [selectedCategory, setSelectedCategory] = useState(STYLE_PRESETS[1]);
  const [customPrompt, setCustomPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>("1:1");
  const [resolution, setResolution] = useState<ImageResolution>("1K");
  const [isBatchGenerating, setIsBatchGenerating] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  
  // Local script state for the error view input
  const [localScript, setLocalScript] = useState(script || '');

  const hasFetchedPresets = useRef(false);

  useEffect(() => {
    setLocalScript(script || '');
  }, [script]);

  // Auto-generate presets if scene exists
  useEffect(() => {
    if (!firstScene) return;
    if (initialVariants.length > 0 || hasFetchedPresets.current) return;
    
    const generateInitialPreviews = async () => {
      hasFetchedPresets.current = true;
      setIsBatchGenerating(true);
      
      const newVariants: StyleVariant[] = [];
      const promises = STYLE_PRESETS.map(async (preset) => {
        // Safe access to firstScene properties
        const synopsis = firstScene?.synopsis || "A generic comic scene";
        const fullPrompt = `A comic panel in this style: ${preset.prompt}. Scene: ${synopsis}`;
        
        try {
          const imageUrl = await generateImage(fullPrompt, "1:1", "1K");
          if (imageUrl) {
            newVariants.push({
              id: preset.id, imageUrl, prompt: preset.prompt, category: preset.label,
              aspectRatio: "1:1", resolution: "1K"
            });
            onVariantsChange([...initialVariants, ...newVariants].sort((a,b) => a.id.localeCompare(b.id)));
          }
        } catch (e) { console.error(`Failed to generate preset ${preset.label}`, e); }
      });
      
      await Promise.all(promises);
      setIsBatchGenerating(false);
    };
    generateInitialPreviews();
  }, [firstScene, initialVariants, onVariantsChange]);

  const handleAnalyzeHere = async () => {
      // Use local script if prop script is empty
      const scriptToAnalyze = localScript || script;
      
      if (!scriptToAnalyze.trim()) {
          setError("Please enter a script to analyze.");
          return;
      }

      setIsAnalyzing(true);
      setError(null);
      try {
          const scenes = await analyzeScript(scriptToAnalyze);
          // Strict check for valid scenes
          if (scenes && scenes.length > 0 && scenes[0].synopsis) {
              if (onScriptUpdate && script !== scriptToAnalyze) {
                  onScriptUpdate(scriptToAnalyze);
              }
              onScenesGenerated(scenes);
          } else {
              setError("Analysis failed. The AI couldn't identify scenes. Please try editing your script to be clearer.");
          }
      } catch (e) {
          setError("Failed to analyze script. Please check your connection.");
      } finally {
          setIsAnalyzing(false);
      }
  };

  const handleGeneratePreview = async () => {
    if (!firstScene) return;
    setIsGenerating(true);
    setError(null);
    try {
      const fullPrompt = `
        Create a comic panel in this style: ${selectedCategory.prompt} ${customPrompt}.
        Scene Description: ${firstScene.synopsis}
        Setting: ${firstScene.setting}
      `;
      
      const imageUrl = await generateImage(fullPrompt, aspectRatio, resolution);
      if (imageUrl) {
        const newVariant: StyleVariant = {
            id: `custom-${Date.now()}`,
            imageUrl,
            prompt: `${selectedCategory.prompt} ${customPrompt}`,
            category: selectedCategory.label,
            aspectRatio,
            resolution
        };
        onVariantsChange([...initialVariants, newVariant]);
      } else {
        setError("No image returned. Please try again.");
      }
    } catch (e: any) {
      setError("Failed to generate image. Check API key permissions and try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  if (!firstScene) {
    return (
        <div className="max-w-7xl mx-auto p-8 text-center space-y-6 animate-fade-in flex flex-col items-center">
            <div className="bg-red-50 border-4 border-red-500 text-red-700 p-8 rounded-xl shadow-comic inline-block transform -rotate-1 max-w-2xl w-full">
                <div className="flex items-center justify-center gap-2 mb-4">
                    <AlertCircle className="w-10 h-10" />
                    <h2 className="text-3xl font-display">Missing Scene Data</h2>
                </div>
                <p className="font-comic text-xl font-bold mb-4">We couldn't find any scenes to generate styles from.</p>
                
                <div className="text-sm bg-white/50 p-4 rounded border-2 border-red-200 mb-6 text-left">
                    <strong className="block mb-1">Why is this happening?</strong>
                    The AI needs to break your script down into "Scenes" before it can start drawing. 
                </div>

                <div className="mb-6">
                    <label className="block text-left font-bold mb-2 text-black">Enter Script Here:</label>
                    <textarea 
                        value={localScript}
                        onChange={(e) => setLocalScript(e.target.value)}
                        className="w-full h-32 p-3 rounded border-2 border-red-300 text-black text-sm"
                        placeholder="Type your story here..."
                    />
                </div>

                <div className="flex gap-4 justify-center">
                    {onBackToScript && (
                        <Button onClick={onBackToScript} variant="outline" className="border-red-700 text-red-700 hover:bg-red-100" icon={<ArrowLeft className="w-4 h-4"/>}>
                            Back
                        </Button>
                    )}
                    <Button 
                        onClick={handleAnalyzeHere} 
                        isLoading={isAnalyzing} 
                        variant="danger"
                        icon={<Wand2 className="w-5 h-5"/>}
                    >
                        Analyze Script Now
                    </Button>
                </div>
                
                 {error && (
                    <div className="mt-4 text-sm font-bold">{error}</div>
                )}
            </div>
        </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-fade-in">
       <div className="text-center space-y-2 bg-white p-4 rounded-xl border-4 border-black shadow-comic w-fit mx-auto transform rotate-1">
        <h2 className="text-3xl font-display text-black uppercase tracking-wider">Style Gallery</h2>
        <p className="text-slate-600 font-comic font-bold">Generate styles and pick your favorite!</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Controls */}
        <div className="lg:w-96 shrink-0 space-y-6 bg-white p-6 rounded-xl border-4 border-black shadow-comic self-start">
            <h3 className="text-2xl font-display text-black">Add New Style</h3>
           <div className="space-y-3">
            <label className="text-lg font-display text-black flex items-center gap-2">
                <Palette className="w-5 h-5" /> Base Style
            </label>
            <div className="grid grid-cols-2 gap-2">
              {STYLE_PRESETS.map((style) => (
                <button
                  key={style.id}
                  onClick={() => setSelectedCategory(style)}
                  className={`p-3 rounded-lg text-xs font-bold text-left transition-all border-2 ${
                    selectedCategory.id === style.id 
                    ? 'bg-brand-yellow border-black text-black shadow-comic scale-105' 
                    : 'bg-white border-slate-200 text-slate-500 hover:border-black hover:text-black'
                  }`}
                >
                  {style.label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-lg font-display text-black">Format</label>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1 uppercase">Aspect Ratio</label>
                    <select value={aspectRatio} onChange={(e) => setAspectRatio(e.target.value as AspectRatio)} className="w-full bg-slate-50 border-2 border-black rounded px-3 py-2 text-sm font-bold text-black focus:ring-0 focus:shadow-comic transition-all">
                        {ASPECT_RATIOS.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                </div>
                <div>
                    <label className="text-xs font-bold text-slate-500 block mb-1 uppercase">Resolution</label>
                    <select value={resolution} onChange={(e) => setResolution(e.target.value as ImageResolution)} className="w-full bg-slate-50 border-2 border-black rounded px-3 py-2 text-sm font-bold text-black focus:ring-0 focus:shadow-comic transition-all">
                        {RESOLUTIONS.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                </div>
            </div>
          </div>

          <div className="space-y-2">
             <label className="text-lg font-display text-black">Tweaks</label>
             <textarea value={customPrompt} onChange={(e) => setCustomPrompt(e.target.value)} placeholder="e.g. more detailed backgrounds..." className="w-full h-24 bg-slate-50 border-2 border-black rounded-lg p-3 text-sm font-medium text-black placeholder-slate-400 focus:ring-0 focus:shadow-comic transition-all resize-none" />
          </div>

          <Button onClick={handleGeneratePreview} isLoading={isGenerating} className="w-full" variant="secondary" icon={<PlusCircle className="w-4 h-4" />}>
            Add to Gallery
          </Button>
        </div>

        {/* Gallery Area */}
        <div className="flex-1 min-h-[500px]">
            {(isBatchGenerating && initialVariants.length === 0) && (
                <div className="w-full h-full flex items-center justify-center bg-white/50 rounded-xl border-4 border-black shadow-comic p-8 backdrop-blur-sm">
                    <div className="text-center">
                        <div className="w-20 h-20 border-8 border-brand-blue border-t-brand-yellow rounded-full animate-spin mx-auto mb-6"></div>
                        <p className="text-3xl font-display text-black animate-bounce">Generating Style Presets...</p>
                    </div>
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {initialVariants.map(variant => {
                    const isSelected = selectedStyleId === variant.id;
                    return (
                        <div key={variant.id} className={`bg-white rounded-xl border-4 shadow-comic group flex flex-col transform transition-all ${isSelected ? 'border-brand-blue ring-4 ring-brand-blue/30 scale-105 z-10' : 'border-black hover:-translate-y-1'}`}>
                            <div className="aspect-square bg-slate-100 relative overflow-hidden border-b-4 border-black rounded-t-lg cursor-pointer" onClick={() => setPreviewImage(variant.imageUrl)}>
                                <img src={variant.imageUrl} alt={variant.category} className="w-full h-full object-cover" />
                                {isSelected && (
                                    <div className="absolute top-2 right-2 bg-brand-blue text-white p-1 rounded-full border-2 border-white shadow-md z-20">
                                        <Check size={20} strokeWidth={3} />
                                    </div>
                                )}
                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end p-4 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                    <div className="w-full pointer-events-auto">
                                        <Button size="sm" variant={isSelected ? "outline" : "primary"} onClick={(e) => { e.stopPropagation(); onStyleConfirmed(variant); }} className="w-full" icon={<Check className="w-4 h-4"/>}>
                                            {isSelected ? "Selected" : "Confirm This Style"}
                                        </Button>
                                    </div>
                                </div>
                            </div>
                            <div className={`p-3 text-center ${isSelected ? 'bg-brand-blue/5' : ''}`}>
                                <div className="flex flex-wrap justify-center items-center gap-2">
                                    <span className="text-xs font-bold bg-brand-blue/20 text-brand-blue px-2 py-1 rounded">{variant.category}</span>
                                    <span className="text-xs font-bold bg-slate-200 text-slate-600 px-2 py-1 rounded">{variant.aspectRatio}</span>
                                    <span className="text-xs font-bold bg-slate-200 text-slate-600 px-2 py-1 rounded">{variant.resolution}</span>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
             {error && (
                <div className="bg-red-50 p-6 rounded-xl border-4 border-brand-red shadow-comic mt-6">
                    <h3 className="text-lg font-display text-brand-red mb-2">Error</h3>
                    <p className="font-comic text-black font-medium">{error}</p>
                </div>
            )}
        </div>
      </div>
      
      {previewImage && <ImagePreviewModal imageUrl={previewImage} onClose={() => setPreviewImage(null)} />}
    </div>
  );
};
