
import React, { useState, useEffect, useRef } from 'react';
import { Users, Wand2, Check, UploadCloud, Download, Image as ImageIcon, CheckSquare, Square, Zap, Box, MapPin } from 'lucide-react';
import { extractWorldDetails, generateImage } from '../../services/geminiService';
import { Scene, Character, Item, Location, ComicState } from '../../types';
import { Button } from '../Button';
import { ImagePreviewModal } from '../modals/ImagePreviewModal';

// Declare HTML2Canvas and jsPDF for downloadable cards
declare const html2canvas: any;
declare const jspdf: any;

const LoaderIcon = () => (
  <svg className="animate-spin h-8 w-8 text-brand-blue" xmlns="http://www.w.org/2000/svg" fill="none" viewBox="0 0 24 24">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
  </svg>
);

interface ReferenceBuilderProps {
  scenes: Scene[];
  currentStyle: ComicState['stylePrompt'];
  initialCharacters: Character[];
  initialItems: Item[];
  initialLocations: Location[];
  onDataUpdate: (data: { characters: Character[], items: Item[], locations: Location[] }) => void;
  onConfirm: () => void;
}

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

type Tab = 'characters' | 'items' | 'locations';

export const ReferenceBuilder: React.FC<ReferenceBuilderProps> = ({ 
    scenes, currentStyle, initialCharacters, initialItems, initialLocations, onDataUpdate, onConfirm 
}) => {
  const [activeTab, setActiveTab] = useState<Tab>('characters');
  const [isLoading, setIsLoading] = useState(initialCharacters.length === 0 && initialItems.length === 0);
  const [generatingId, setGeneratingId] = useState<string | null>(null);
  const [isBatchGenerating, setIsBatchGenerating] = useState(false);
  const [previewImage, setPreviewImage] = useState<{url: string, title: string} | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const hasFetched = useRef(initialCharacters.length > 0);

  useEffect(() => {
    if (hasFetched.current) return;
    hasFetched.current = true;

    const fetchWorld = async () => {
      try {
        const data = await extractWorldDetails(scenes);
        onDataUpdate(data);
      } catch (e) {
        console.error(e);
      } finally {
        setIsLoading(false);
      }
    };
    fetchWorld();
  }, [scenes, onDataUpdate]);

  // Generic handlers for updating any entity list
  const updateEntity = (type: Tab, id: string, updates: any) => {
      if (type === 'characters') {
          onDataUpdate({ characters: initialCharacters.map(c => c.id === id ? { ...c, ...updates } : c), items: initialItems, locations: initialLocations });
      } else if (type === 'items') {
          onDataUpdate({ characters: initialCharacters, items: initialItems.map(i => i.id === id ? { ...i, ...updates } : i), locations: initialLocations });
      } else {
          onDataUpdate({ characters: initialCharacters, items: initialItems, locations: initialLocations.map(l => l.id === id ? { ...l, ...updates } : l) });
      }
  };

  const handleRefUpload = async (type: Tab, id: string, files: FileList | null) => {
    if (!files) return;
    const fileArray = Array.from(files).slice(0, 3);
    const base64s = await Promise.all(fileArray.map(fileToBase64));
    
    const list = type === 'characters' ? initialCharacters : type === 'items' ? initialItems : initialLocations;
    const entity = list.find(e => e.id === id);
    if (entity) {
        updateEntity(type, id, { referenceImages: [...entity.referenceImages, ...base64s].slice(0, 3) });
    }
  };

  const generateEntityImage = async (type: Tab, entity: any) => {
      setGeneratingId(entity.id);
      try {
          const prompt = `
            Concept Art for ${type === 'characters' ? 'Character' : type === 'items' ? 'Item' : 'Location'}: ${entity.name}.
            Visual Description: ${entity.description}.
            Style: ${currentStyle}.
            Full detail, neutral background, professional concept art sheet.
          `;
          const url = await generateImage(prompt, "1:1", "1K", entity.referenceImages);
          if (url) updateEntity(type, entity.id, { imageUrl: url });
      } catch (e) { console.error(e); }
      finally { setGeneratingId(null); }
  };
  
  const handleGenerateAll = async () => {
      const list = activeTab === 'characters' ? initialCharacters : activeTab === 'items' ? initialItems : initialLocations;
      const entitiesToGenerate = list.filter(e => !e.imageUrl);
      if (entitiesToGenerate.length === 0) return;

      setIsBatchGenerating(true);
      for(const entity of entitiesToGenerate) {
          await generateEntityImage(activeTab, entity);
      }
      setIsBatchGenerating(false);
  };

  const downloadCardAs = async (elementId: string, name: string, format: 'pdf' | 'image') => {
      const element = document.getElementById(elementId);
      if (!element) return;
      
      try {
          const canvas = await html2canvas(element, { scale: 2, backgroundColor: '#ffffff' });
          if (format === 'image') {
              const imgData = canvas.toDataURL('image/png');
              const link = document.createElement('a');
              link.download = `${name.replace(/\s+/g, '_')}_card.png`;
              link.href = imgData;
              link.click();
          } else {
              const { jsPDF } = jspdf;
              const pdf = new jsPDF('p', 'mm', 'a5');
              const imgData = canvas.toDataURL('image/png');
              const pdfWidth = pdf.internal.pageSize.getWidth();
              const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
              pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
              pdf.save(`${name.replace(/\s+/g, '_')}_card.pdf`);
          }
      } catch (e) { console.error("Download failed", e); }
  };

  const downloadSelectedAsPDF = async () => {
      if (selectedIds.size === 0) return;
      const { jsPDF } = jspdf;
      const pdf = new jsPDF('p', 'mm', 'a5');
      let isFirstPage = true;

      for (const id of selectedIds) {
          const element = document.getElementById(`card-${id}`);
          if (element) {
              if (!isFirstPage) {
                  pdf.addPage();
              }
              const canvas = await html2canvas(element, { scale: 2, backgroundColor: '#ffffff' });
              const imgData = canvas.toDataURL('image/png');
              const pdfWidth = pdf.internal.pageSize.getWidth();
              const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
              pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
              isFirstPage = false;
          }
      }
      pdf.save(`DreamStream_Collection.pdf`);
  };

  const toggleSelection = (id: string) => {
      const newSelection = new Set(selectedIds);
      if (newSelection.has(id)) {
          newSelection.delete(id);
      } else {
          newSelection.add(id);
      }
      setSelectedIds(newSelection);
  };

  const renderEntityCard = (entity: any, type: Tab) => {
      const isSelected = selectedIds.has(entity.id);
      return (
      <div id={`card-${entity.id}`} key={entity.id} className="bg-white rounded-xl border-4 shadow-comic overflow-hidden flex flex-col relative group">
         {/* Selection Checkbox */}
         <div 
            className="absolute top-3 left-3 z-20 cursor-pointer"
            onClick={() => toggleSelection(entity.id)}
         >
            {isSelected ? <CheckSquare className="w-8 h-8 text-white bg-brand-blue rounded-md border-2 border-white shadow-lg"/> : <Square className="w-8 h-8 text-black bg-white/70 rounded-md opacity-50 group-hover:opacity-100"/>}
         </div>

         {/* Image Area */}
         <div className="aspect-square bg-slate-100 relative border-b-4 border-black cursor-pointer" onClick={() => entity.imageUrl && setPreviewImage({ url: entity.imageUrl, title: entity.name })}>
             {entity.imageUrl ? (
                 <img src={entity.imageUrl} className="w-full h-full object-cover" />
             ) : (
                 <div className="w-full h-full flex items-center justify-center text-slate-300 bg-[radial-gradient(#cbd5e1_1px,transparent_1px)] [background-size:10px_10px]">
                     {type === 'characters' ? <Users size={40}/> : type === 'items' ? <Box size={40}/> : <MapPin size={40}/>}
                 </div>
             )}
             {generatingId === entity.id && <div className="absolute inset-0 bg-white/80 flex items-center justify-center backdrop-blur-sm"><LoaderIcon/></div>}
         </div>

         {/* Content Area */}
         <div className="p-5 flex-1 flex flex-col gap-4 bg-white">
             <div>
                 <input 
                    value={entity.name} 
                    onChange={(e) => updateEntity(type, entity.id, { name: e.target.value })}
                    className="w-full font-display text-2xl border-b-2 border-transparent hover:border-black focus:border-brand-blue outline-none bg-transparent"
                 />
                 <textarea 
                    value={entity.bio || entity.description} // Fallback for items/locs that might not have bio
                    onChange={(e) => updateEntity(type, entity.id, { [type === 'characters' ? 'bio' : 'description']: e.target.value })}
                    className="w-full text-sm font-comic text-slate-600 mt-2 resize-none bg-transparent border-2 border-transparent hover:border-slate-200 focus:border-brand-blue rounded p-1"
                    rows={3}
                    placeholder="Enter description..."
                 />
             </div>
             
             {/* Refs */}
             <div className="flex gap-2">
                 {entity.referenceImages.map((img: string, i: number) => (
                     <img key={i} src={img} className="w-10 h-10 rounded border border-black object-cover" />
                 ))}
                 <label className="w-10 h-10 flex items-center justify-center border-2 border-dashed border-slate-400 rounded cursor-pointer hover:bg-slate-100">
                     <UploadCloud size={16} className="text-slate-400"/>
                     <input type="file" hidden multiple onChange={(e) => handleRefUpload(type, entity.id, e.target.files)}/>
                 </label>
             </div>
             
             <div className="grid grid-cols-3 gap-2 mt-auto">
                 <Button size="sm" variant="secondary" onClick={() => generateEntityImage(type, entity)} icon={<Wand2 size={14}/>}>Gen</Button>
                 <Button size="sm" variant="outline" onClick={() => downloadCardAs(`card-${entity.id}`, entity.name, 'image')} icon={<ImageIcon size={14}/>}>Img</Button>
                 <Button size="sm" variant="outline" onClick={() => downloadCardAs(`card-${entity.id}`, entity.name, 'pdf')} icon={<Download size={14}/>}>PDF</Button>
             </div>
         </div>
      </div>
  )};

  if (isLoading) {
    return (
        <div className="flex flex-col items-center justify-center py-20 space-y-6 bg-white rounded-xl border-4 border-black shadow-comic max-w-2xl mx-auto">
             <div className="animate-spin w-12 h-12 border-4 border-brand-blue border-t-transparent rounded-full"></div>
             <p className="font-display text-xl">Scouting Locations & Casting Actors...</p>
        </div>
    )
  }

  const activeList = activeTab === 'characters' ? initialCharacters : activeTab === 'items' ? initialItems : initialLocations;

  return (
    <div className="max-w-6xl mx-auto space-y-6 animate-fade-in">
       <div className="bg-white p-4 rounded-xl border-4 border-black shadow-comic flex flex-col md:flex-row justify-between items-center gap-4">
           <div>
               <h2 className="text-3xl font-display">World Builder</h2>
               <p className="text-slate-600 font-comic">Define your cast, props, and locations.</p>
           </div>
           <div className="flex flex-wrap items-center gap-4">
             <div className="flex gap-2 bg-slate-100 p-1 rounded-lg border-2 border-black">
                 {['characters', 'items', 'locations'].map((t) => (
                     <button
                      key={t}
                      onClick={() => { setActiveTab(t as Tab); setSelectedIds(new Set()); }}
                      className={`px-4 py-2 rounded font-bold uppercase text-xs transition-all ${activeTab === t ? 'bg-brand-yellow text-black shadow-sm border border-black' : 'text-slate-500 hover:text-black'}`}
                     >
                         {t}
                     </button>
                 ))}
             </div>
             {selectedIds.size > 0 ? (
                 <Button onClick={downloadSelectedAsPDF} icon={<Download/>}>Download {selectedIds.size} as PDF</Button>
             ) : (
                <Button onClick={handleGenerateAll} isLoading={isBatchGenerating} icon={<Wand2/>}>Generate All</Button>
             )}
             <Button onClick={onConfirm} variant="primary">Confirm World <Check className="ml-2 w-4 h-4"/></Button>
           </div>
       </div>

       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
           {activeList.map(entity => renderEntityCard(entity, activeTab))}
       </div>
       
       {previewImage && <ImagePreviewModal imageUrl={previewImage.url} title={previewImage.title} onClose={() => setPreviewImage(null)} />}
    </div>
  );
};
