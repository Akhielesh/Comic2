
import React from 'react';
import { Play, Clock, Coins, AlertCircle, FileText, ImageIcon, Layers } from 'lucide-react';
import { ComicState } from '../../types';
import { Button } from '../Button';

interface CombinedPreviewProps {
  state: ComicState;
  onConfirm: () => void;
}

export const CombinedPreview: React.FC<CombinedPreviewProps> = ({ state, onConfirm }) => {
  // --- ACCURATE ESTIMATION MATH ---
  
  // 1. Token Calculation
  // Standard rule: 1 word approx 1.33 tokens
  const wordCount = state.script.trim().split(/\s+/).length;
  const inputTokens = Math.ceil(wordCount * 1.33);
  
  // 2. Image/Panel Calculation
  // The AI generator (generationManager) creates roughly 3-4 panels per scene.
  // We use 3.5 as a safe average multiplier.
  const estimatedPanels = Math.ceil(state.scenes.length * 3.5);

  // 3. Time Estimation
  // Gemini 3 Pro Image takes approx 8-12 seconds per image.
  // Flash Lite (text logic) takes approx 3 seconds per scene.
  const totalSeconds = (estimatedPanels * 10) + (state.scenes.length * 3);
  const estTimeMinutes = Math.ceil(totalSeconds / 60);

  // 4. Cost Estimation (Based on Gemini Pricing)
  // Input Audio/Video is 0. Input Text is $1.25 / 1M tokens (negligible for 10k words)
  // Output Image (Gemini 3 Pro) is approx $0.04 per image.
  // Output Text (Flash Lite) is negligible.
  const costInputText = (inputTokens / 1000000) * 1.25; 
  const costImages = estimatedPanels * 0.04; 
  const estTotalCost = costInputText + costImages;

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fade-in">
        <div className="text-center space-y-4">
            <h2 className="text-4xl font-display text-black">Pre-Flight Check</h2>
            <p className="text-xl font-comic text-slate-600">Review estimates for your <strong>{wordCount.toLocaleString()} word</strong> script.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column: Visual Specs */}
            <div className="lg:col-span-2 space-y-6">
                
                {/* Visual Summary Card */}
                <div className="bg-white p-6 rounded-xl border-4 border-black shadow-comic flex flex-col md:flex-row gap-6">
                     <div className="w-32 h-32 rounded border-2 border-black overflow-hidden bg-slate-100 shrink-0">
                        {state.styleVariants.find(s => s.id === state.selectedStyleId)?.imageUrl && (
                            <img src={state.styleVariants.find(s => s.id === state.selectedStyleId)!.imageUrl} className="w-full h-full object-cover"/>
                        )}
                    </div>
                    <div className="flex-1 space-y-3">
                        <div className="flex justify-between items-start">
                            <div>
                                <h3 className="font-display text-2xl">{state.styleCategory}</h3>
                                <p className="text-xs font-bold text-slate-500 uppercase">{state.styleAspectRatio} • {state.layoutType} Layout</p>
                            </div>
                            <span className="bg-brand-blue text-white text-xs font-bold px-2 py-1 rounded border border-black">
                                {state.imageResolution}
                            </span>
                        </div>
                        <div className="p-3 bg-slate-50 rounded border-2 border-slate-200 text-sm italic text-slate-600">
                            "{state.stylePrompt}"
                        </div>
                    </div>
                </div>

                {/* Script Summary (AI Understanding) */}
                <div className="bg-white rounded-xl border-4 border-black shadow-comic overflow-hidden">
                    <div className="bg-slate-100 p-4 border-b-4 border-black flex justify-between items-center">
                        <h3 className="font-display text-xl flex items-center gap-2">
                            <FileText size={20}/> Script Breakdown
                        </h3>
                        <span className="text-xs font-bold bg-white px-2 py-1 rounded border border-black">
                            {state.scenes.length} Scenes Detected
                        </span>
                    </div>
                    <div className="max-h-64 overflow-y-auto custom-scrollbar p-0">
                        {state.scenes.map((scene, i) => (
                            <div key={scene.id} className="p-4 border-b border-slate-200 last:border-0 hover:bg-yellow-50 transition-colors">
                                <div className="flex items-center gap-2 mb-1">
                                    <span className="font-display text-lg text-brand-blue">Scene {i + 1}</span>
                                    <span className="text-xs font-bold bg-slate-200 px-2 py-0.5 rounded text-slate-600">{scene.setting}</span>
                                </div>
                                <p className="text-sm text-slate-700 font-medium mb-2">{scene.synopsis}</p>
                                <div className="flex flex-wrap gap-1">
                                    {scene.characters.map((char, idx) => (
                                        <span key={idx} className="text-[10px] font-bold uppercase bg-brand-yellow/30 px-1.5 py-0.5 rounded border border-brand-yellow text-amber-900">
                                            {char}
                                        </span>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Right Column: Calculations */}
            <div className="space-y-6">
                <div className="bg-brand-yellow p-6 rounded-xl border-4 border-black shadow-comic relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-10">
                        <Coins size={100} />
                    </div>
                    <h3 className="text-2xl font-display mb-6 border-b-2 border-black pb-2">Generation Estimate</h3>
                    
                    <div className="space-y-4 relative z-10">
                        {/* Images */}
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 font-bold text-sm">
                                <ImageIcon size={16}/> Output Images
                            </div>
                            <div className="font-mono font-bold text-xl">~{estimatedPanels}</div>
                        </div>
                         <div className="text-xs text-amber-900 text-right -mt-2 mb-4 font-mono">
                            Based on {state.scenes.length} scenes × 3.5 panels
                        </div>

                        {/* Tokens */}
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 font-bold text-sm">
                                <Layers size={16}/> Input Tokens
                            </div>
                            <div className="font-mono">~{inputTokens.toLocaleString()}</div>
                        </div>

                        <hr className="border-black/20"/>

                        {/* Time */}
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 font-bold text-sm">
                                <Clock size={16}/> Est. Time
                            </div>
                            <div className="font-mono bg-white px-2 py-0.5 rounded border border-black">
                                {estTimeMinutes} min
                            </div>
                        </div>

                        {/* Cost */}
                        <div className="flex items-center justify-between bg-white p-3 rounded-lg border-2 border-black shadow-sm transform scale-105">
                            <div className="flex items-center gap-2 font-bold text-sm">
                                <Coins size={16} className="text-brand-yellow fill-black"/> Est. API Cost
                            </div>
                            <div className="font-mono font-bold text-2xl text-green-600">
                                ${estTotalCost.toFixed(2)}
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-white p-4 rounded-xl border-4 border-black shadow-comic flex gap-3 items-start">
                    <AlertCircle className="text-brand-blue shrink-0 mt-1"/>
                    <p className="text-xs font-comic text-slate-700 leading-relaxed">
                        <strong>Note:</strong> Costs are estimated based on Gemini 3 Pro pricing ($0.04/image). Actual usage may vary based on retries and prompt density.
                    </p>
                </div>

                <Button onClick={onConfirm} className="w-full py-6 text-xl" icon={<Play fill="currentColor"/>}>
                    Start Generation
                </Button>
            </div>
        </div>
    </div>
  );
};
