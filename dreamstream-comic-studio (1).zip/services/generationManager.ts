import { ComicState, Project, GenerationStatus, ComicPanel, Scene } from "../types";
import { generatePanelBreakdown, generateImage } from "./geminiService";

// We use a global map to track active abort controllers if we wanted to support cancellation
// For now, we just let them run.

export const startBackgroundGeneration = async (
  project: Project,
  onUpdate: (projectId: string, updates: Partial<Project> | ((prev: Project) => Partial<Project>)) => void,
  onComplete: (projectId: string, panels: ComicPanel[]) => void
) => {
  const state = project.state;
  const startTime = Date.now();
  
  // Initialize Status
  let currentStatus: GenerationStatus = {
    isActive: true,
    progress: 0,
    startTime,
    estimatedTimeRemaining: "Calculating...",
    currentStepDescription: "Initializing...",
    logs: [],
    completedPanels: 0,
    totalPanels: state.scenes.length * 4 // Estimate
  };

  const updateStatus = (overrides: Partial<GenerationStatus>) => {
    currentStatus = { ...currentStatus, ...overrides };
    onUpdate(project.id, (prev) => ({
      state: { ...prev.state, generationStatus: currentStatus }
    }));
  };

  const addLog = (message: string) => {
    const newLog = { timestamp: Date.now(), message };
    updateStatus({ logs: [...currentStatus.logs, newLog] });
  };

  try {
    addLog("Starting generation process...");
    const allPanels: ComicPanel[] = [...state.panels]; // Keep existing if any, or start fresh? Usually fresh build clears old panels or appends?
    // We'll assume a fresh build or append. Let's clear for "Full Generation" mode.
    // But if we want to support partial, we'd need logic. For now, fresh build of all scenes.
    const freshPanels: ComicPanel[] = [];

    let totalStepsEstimate = state.scenes.length * 4; // 1 step breakdown + ~3 panels
    let stepsCompleted = 0;

    for (const scene of state.scenes) {
      if (!scene || !scene.synopsis) {
          addLog(`Skipping invalid scene data...`);
          continue;
      }

      updateStatus({ currentStepDescription: `Analyzing Scene ${scene.id}` });
      addLog(`Analyzing Scene ${scene.id}: ${scene.synopsis.substring(0, 30)}...`);

      // 1. Breakdown
      const breakdown = await generatePanelBreakdown(scene, state.stylePrompt, state.layoutType);
      
      // Adjust estimate based on actual panel count
      totalStepsEstimate = totalStepsEstimate - 3 + breakdown.length; // Adjust total
      stepsCompleted++; // Breakdown done

      for (const panelData of breakdown) {
        const panelId = `s${scene.id}-p${freshPanels.length}-${Date.now()}`;
        
        updateStatus({ currentStepDescription: `Generating visual for Scene ${scene.id}` });
        addLog(`Painting Panel: ${panelData.description.substring(0, 30)}...`);

        const characterContext = state.characters.map(c => `${c.name}: ${c.description}`).join('. ');
        const itemContext = state.items.map(i => `${i.name}: ${i.description}`).join('. ');
        const locContext = state.locations.map(l => `${l.name}: ${l.description}`).join('. ');

        const imagePrompt = `
            Comic Panel. Style: ${state.stylePrompt}.
            Layout: ${state.layoutType === 'custom' ? state.customLayoutPrompt : state.layoutType}.
            Characters: ${characterContext}.
            Items: ${itemContext}.
            Locations: ${locContext}.
            Scene Action: ${panelData.description}. Setting: ${scene.setting}.
            Ensure character visual consistency based on provided references.
        `;

        const imageUrl = await generateImage(imagePrompt, state.styleAspectRatio, state.imageResolution);

        const newPanel: ComicPanel = {
          id: panelId, 
          sceneId: scene.id, 
          description: panelData.description,
          dialogue: panelData.dialogue, 
          imageUrl, 
          imageUrlHistory: imageUrl ? [imageUrl] : []
        };
        
        freshPanels.push(newPanel);
        
        // Update Progress and Panels in State immediately so user sees them appearing
        stepsCompleted++;
        
        // Calculate Estimate
        const elapsedSeconds = (Date.now() - startTime) / 1000;
        const ratePerStep = elapsedSeconds / stepsCompleted;
        const remainingSteps = totalStepsEstimate - stepsCompleted;
        const estSecondsLeft = remainingSteps * ratePerStep;
        
        const timeString = estSecondsLeft < 60 
            ? `${Math.ceil(estSecondsLeft)}s` 
            : `${Math.ceil(estSecondsLeft / 60)}m ${Math.ceil(estSecondsLeft % 60)}s`;

        updateStatus({
            progress: (stepsCompleted / totalStepsEstimate) * 100,
            estimatedTimeRemaining: timeString,
            completedPanels: freshPanels.length,
            totalPanels: totalStepsEstimate // Approximate
        });

        // Push panels to project state progressively
        onUpdate(project.id, (prev) => ({
            state: { ...prev.state, panels: freshPanels }
        }));
      }
    }

    addLog("Build Complete!");
    updateStatus({ 
        isActive: false, 
        progress: 100, 
        estimatedTimeRemaining: "Done",
        currentStepDescription: "Complete" 
    });
    
    onComplete(project.id, freshPanels);

  } catch (error) {
    console.error("Generation Error", error);
    addLog(`Error: ${error}`);
    updateStatus({ isActive: false, currentStepDescription: "Failed" });
  }
};