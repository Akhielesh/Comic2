
import { GoogleGenAI, Type, Chat } from "@google/genai";
import { Scene, Character, Item, Location, AspectRatio, ImageResolution, Project, AppStep } from "../types";

// Helper to get AI instance safely
const getAI = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found. Please set process.env.API_KEY.");
  }
  return new GoogleGenAI({ apiKey });
};

// Robust JSON Extractor: Finds the first valid JSON array or object in the text
const extractJson = (text: string): any => {
  try {
    // 1. Try cleaning markdown code blocks first
    const cleanMarkdown = text.replace(/```json\n?|\n?```/g, "").trim();
    // 2. Try parsing directly
    return JSON.parse(cleanMarkdown);
  } catch (e) {
    // 3. Fallback: Regex extraction for arrays or objects
    try {
      const arrayMatch = text.match(/\[\s*\{[\s\S]*\}\s*\]/);
      if (arrayMatch) return JSON.parse(arrayMatch[0]);
      
      const objectMatch = text.match(/\{[\s\S]*\}/);
      if (objectMatch) return JSON.parse(objectMatch[0]);
      
      throw new Error("No JSON found in response");
    } catch (error) {
      console.error("Failed to extract JSON from:", text);
      throw error;
    }
  }
};

// Utility to convert a base64 string to a GenerativePart
const fileToGenerativePart = (base64: string, mimeType: string) => {
    return {
      inlineData: {
        data: base64.split(',')[1],
        mimeType
      },
    };
};

// 1. Analyze Script
export const analyzeScript = async (script: string): Promise<Scene[]> => {
  const ai = getAI();
  
  const prompt = `
    Analyze the following comic script. Break it down into individual scenes.
    For each scene, provide:
    1. A synopsis (visual description of what happens).
    2. A list of characters present.
    3. The setting/location.
    
    Script:
    ${script}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 2048 }, // Reduced slightly to balance speed/parsing
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.INTEGER },
              rawText: { type: Type.STRING },
              synopsis: { type: Type.STRING },
              characters: { type: Type.ARRAY, items: { type: Type.STRING } },
              setting: { type: Type.STRING }
            },
            required: ["id", "synopsis", "characters", "setting"]
          }
        }
      }
    });

    if (response.text) {
        const rawScenes = extractJson(response.text);
        // Strict Validation
        if (Array.isArray(rawScenes)) {
            return rawScenes.filter(s => s && s.synopsis && s.setting); // Filter out broken scenes
        }
    }
    return [];
  } catch (e) {
    console.error("Analysis Error:", e);
    return [];
  }
};

// 2. Extract World Details (Characters, Items, Locations)
export const extractWorldDetails = async (scenes: Scene[]): Promise<{
    characters: Character[],
    items: Item[],
    locations: Location[]
}> => {
  if (!scenes || scenes.length === 0) {
      console.warn("extractWorldDetails called with no scenes");
      return { characters: [], items: [], locations: [] };
  }

  const ai = getAI();
  
  const sceneContext = scenes.map(s => `Scene ${s.id}: ${s.synopsis} (Chars: ${s.characters?.join(', ') || ''})`).join('\n');
  const prompt = `
    Based on these scenes, extract the visual definitions for the comic.
    
    1. Characters: Identify main characters. Include a short bio (personality/backstory) and a precise visual description for an artist.
    2. Items: Identify key props or items that appear (e.g., weapons, artifacts, vehicles).
    3. Locations: Identify key recurring settings/backgrounds.
    
    Scenes:
    ${sceneContext}
  `;

  try {
    const response = await ai.models.generateContent({
        model: "gemini-3-pro-preview",
        contents: prompt,
        config: {
            thinkingConfig: { thinkingBudget: 4096 },
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    characters: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                id: { type: Type.STRING },
                                name: { type: Type.STRING },
                                bio: { type: Type.STRING },
                                description: { type: Type.STRING }
                            },
                            required: ["id", "name", "bio", "description"]
                        }
                    },
                    items: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                id: { type: Type.STRING },
                                name: { type: Type.STRING },
                                description: { type: Type.STRING }
                            },
                            required: ["id", "name", "description"]
                        }
                    },
                    locations: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                id: { type: Type.STRING },
                                name: { type: Type.STRING },
                                description: { type: Type.STRING }
                            },
                            required: ["id", "name", "description"]
                        }
                    }
                },
                required: ["characters", "items", "locations"]
            }
        }
    });

    if (response.text) {
        const data = extractJson(response.text);
        return {
            characters: (data.characters || []).map((c: any) => ({...c, referenceImages: []})),
            items: (data.items || []).map((i: any) => ({...i, referenceImages: []})),
            locations: (data.locations || []).map((l: any) => ({...l, referenceImages: []}))
        };
    }
  } catch (e) {
      console.error("JSON Parse Error in extractWorldDetails", e);
  }
  return { characters: [], items: [], locations: [] };
};

// 3. Generate Image
export const generateImage = async (
  prompt: string, 
  aspectRatio: AspectRatio = "1:1",
  resolution: ImageResolution = "1K",
  referenceImages: string[] = []
): Promise<string | undefined> => {
  const ai = getAI();
  const textPart = { text: prompt };
  const imageParts = referenceImages.map(img => fileToGenerativePart(img, 'image/jpeg'));

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-image-preview",
      contents: {
        parts: [textPart, ...imageParts]
      },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio,
          imageSize: resolution
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
  } catch (error) {
    console.error("Image generation failed:", error);
    // Don't throw, just return undefined so UI handles it gracefully
    return undefined;
  }
  return undefined;
};

// 4. Generate Panel Breakdown
export const generatePanelBreakdown = async (scene: Scene, style: string, layoutType: string): Promise<Array<{ description: string; dialogue: string }>> => {
    if (!scene || !scene.synopsis) {
        console.error("generatePanelBreakdown called with invalid scene", scene);
        return [];
    }
    
    const ai = getAI();
    // Using Flash Lite for speed on breakdown
    const model = "gemini-2.5-flash-lite"; 
    
    const prompt = `
      Act as a comic book editor.
      Break this scene into 2-4 distinct comic panels based on the synopsis.
      Style: ${style}.
      Layout: ${layoutType}.
      
      Scene Synopsis: ${scene.synopsis}
      
      Return JSON array of panels.
    `;
  
    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            description: { type: Type.STRING, description: "Visual prompt for the artist" },
                            dialogue: { type: Type.STRING, description: "Speech bubble text or caption" }
                        }
                    }
                }
            }
        });
    
        if (response.text) {
            return extractJson(response.text) || [];
        }
    } catch (e) {
        console.error("Panel Breakdown Error:", e);
    }
    return [];
  };

// 5. Analyze Layout
export const analyzeLayoutFromImages = async (images: string[]): Promise<string> => {
    const ai = getAI();
    const imageParts = images.map(img => fileToGenerativePart(img, 'image/jpeg'));
    
    const contents = { parts: [
        { text: "Analyze these images of comic book pages. Describe the panel layout verbally in a single sentence. This description will be used as a creative brief for a comic generation AI. Example: 'A large horizontal panel at the top, with two smaller square panels underneath it.'" },
        ...imageParts
    ]};
    
    const response = await ai.models.generateContent({
        model: "gemini-3-pro-preview",
        contents: contents,
    });
    return response.text || "Could not analyze layout.";
};

// 6. Chat
export const startChatWithScript = (script: string): Chat => {
    const ai = getAI();
    return ai.chats.create({
        model: "gemini-2.5-flash",
        config: {
            systemInstruction: `You are an AI Assistant for a comic book. 
            You have access to the script of the story. 
            Your job is to answer reader questions about the plot, characters, and world, strictly based on the script provided. 
            Do not invent facts. If the script doesn't say, say you don't know.
            Be fun and engaging, like a fan club president.
            
            The Script:
            ${script}
            `
        }
    });
};

// 7. Master App Assistant
export const queryMasterAssistant = async (
    userMessage: string,
    history: {role: 'user'|'model', text: string}[],
    context: {
        view: string;
        project?: Project;
        systemStatus?: any;
    }
): Promise<string> => {
    const ai = getAI();

    // Simplify context to avoid hitting token limits
    const projectSummary = context.project ? {
        name: context.project.name,
        step: AppStep[context.project.state.step],
        scenesCount: context.project.state.scenes.length,
        charsCount: context.project.state.characters.length,
        panelsCount: context.project.state.panels.length,
        isGenerating: context.project.state.generationStatus?.isActive,
        scriptLength: context.project.state.script.length
    } : "No active project";

    const systemPrompt = `
        You are the "DreamStream Master Assistant".
        You are an expert on the DreamStream Comic Studio web application.
        You have access to the user's realtime application state.

        Your goals:
        1. Help the user navigate the app.
        2. Debug issues (e.g., if Scenes count is 0 and they are in Style step, tell them to go back to Script).
        3. Explain features (e.g., "World Builder allows you to create character sheets").
        4. Be encouraging and creative.

        Current App State:
        - View: ${context.view}
        - Project Summary: ${JSON.stringify(projectSummary)}
        
        If the user asks "What is wrong?", look at the Project Summary. 
        - If scriptLength is 0, they need to write a script.
        - If scenesCount is 0 but they are past the script step, they probably skipped analysis.
        - If isGenerating is true, tell them to wait.
    `;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
            { role: 'user', parts: [{ text: systemPrompt }] }, // Seed context
            ...history.map(h => ({ role: h.role, parts: [{ text: h.text }] })),
            { role: 'user', parts: [{ text: userMessage }] }
        ]
    });

    return response.text || "I'm having trouble connecting to the studio mainframe.";
};
